package com.verifypoint.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var splash: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var errorPanel: LinearLayout
    private var pageFailed = false
    private val homeUrl = "https://verifypoint.xdyn.com/"
    private val trustedHost = "verifypoint.xdyn.com"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 42, 74)
        window.navigationBarColor = Color.rgb(8, 42, 74)

        root = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportMultipleWindows(false)
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false
                if (scheme == "https" && uri.host.equals(trustedHost, ignoreCase = true)) return false
                // Only the exact VerifyPoint website is kept inside the app. Other links are opened externally.
                return openExternal(uri)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                pageFailed = false
                errorPanel.visibility = View.GONE
                progress.visibility = View.VISIBLE
                progress.progress = 0
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                splash.visibility = View.GONE
                if (!pageFailed) errorPanel.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    pageFailed = true
                    splash.visibility = View.GONE
                    errorPanel.visibility = View.VISIBLE
                    progress.visibility = View.GONE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, FrameLayout.LayoutParams(-1, dp(4), Gravity.TOP))

        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(24), dp(28), dp(24))
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
        }
        val errorTitle = TextView(this).apply {
            text = "Unable to connect"
            textSize = 22f
            setTextColor(Color.rgb(13, 55, 116))
            gravity = Gravity.CENTER
        }
        val errorMessage = TextView(this).apply {
            text = "Please check your internet connection and try again."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(20))
        }
        val retryButton = Button(this).apply {
            text = "Retry"
            setOnClickListener {
                errorPanel.visibility = View.GONE
                splash.visibility = View.VISIBLE
                webView.loadUrl(homeUrl)
            }
        }
        errorPanel.addView(errorTitle)
        errorPanel.addView(errorMessage)
        errorPanel.addView(retryButton)
        root.addView(errorPanel, FrameLayout.LayoutParams(-1, -1))

        splash = ImageView(this).apply {
            setImageResource(R.drawable.verify_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(18), dp(18), dp(18), dp(18))
            contentDescription = "VerifyPoint — Fast, Secure, Trusted"
        }
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(homeUrl)
        }
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
            true
        } catch (_: Exception) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
            true
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Use Android's back dispatcher when migrating to newer activity APIs")
    override fun onBackPressed() {
        if (errorPanel.visibility == View.VISIBLE) {
            errorPanel.visibility = View.GONE
            splash.visibility = View.VISIBLE
            webView.loadUrl(homeUrl)
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
