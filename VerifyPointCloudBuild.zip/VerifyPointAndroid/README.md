# VerifyPoint Android app source

**App:** VerifyPoint  
**Tagline:** FAST • SECURE • TRUSTED  
**Website:** https://verifypoint.xdyn.com/

This is the Android WebView app source project. It includes the supplied VerifyPoint logo, launcher icon assets, a branded launch overlay, progress indicator, website navigation, back-button behavior, and a retry screen for main-frame connection errors.

## Build requirements
- Android Studio (stable)
- Android SDK Platform 35
- JDK 17 (Android Studio's bundled JDK is recommended)
- Internet connection for Gradle dependency and SDK downloads

## Build an APK
1. Extract the ZIP archive.
2. In Android Studio, select **Open** and open the `VerifyPointAndroid` folder.
3. Wait for Gradle sync. If prompted, install Android SDK Platform 35/build tools.
4. To run on a phone, connect it with USB debugging enabled and click **Run**.
5. To create an installable APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show a notification with **Locate** to find the generated APK. The usual debug APK path is `app/build/outputs/apk/debug/app-debug.apk`.

## App behavior
- Loads the HTTPS VerifyPoint site in an embedded WebView
- Enables JavaScript and DOM storage for site compatibility
- Keeps the exact VerifyPoint host inside the app; opens other links through Android's external handlers
- Shows a horizontal loading progress bar
- Provides an error/retry panel when the main page fails to load
- Supports WebView state saving and Android back navigation
- Disables WebView file/content access and mixed content


## Important status
This environment has no Android SDK, Gradle installation, or Android build cache, so an APK cannot be compiled or device-tested here. The project source is prepared, but the resulting APK still needs to be built with Android Studio or another Android build environment. This source is a website-wrapper app; it does not implement a separate identity-verification backend or native biometric functionality.

## Before publishing
Test login, verification/payment flows, redirects, WhatsApp/support links, screen rotation, and the privacy policy on real devices. Confirm that all service/API use is authorized. Review Android 15 target behavior and Play Store requirements before release.
